extends StaticBody2D
class_name WorldChunk

var index: int = 0
var heights: PackedFloat32Array = PackedFloat32Array()


func build(chunk_index: int) -> void:
	index = chunk_index
	position = Vector2(chunk_index * Game.CHUNK_TILES * Game.TILE, 0)
	heights.resize(Game.CHUNK_TILES + 1)
	for i in range(Game.CHUNK_TILES + 1):
		var wt := chunk_index * Game.CHUNK_TILES + i
		heights[i] = Game.ground_height(wt)
	_build_collision()
	z_index = -2
	queue_redraw()


func _build_collision() -> void:
	var poly := CollisionPolygon2D.new()
	var pts := PackedVector2Array()
	var w := Game.CHUNK_TILES * Game.TILE
	for i in range(Game.CHUNK_TILES + 1):
		pts.append(Vector2(i * Game.TILE, heights[i]))
	pts.append(Vector2(w, 1400))
	pts.append(Vector2(0, 1400))
	poly.polygon = pts
	add_child(poly)


func _draw() -> void:
	var w := Game.CHUNK_TILES
	var stone := Color(0.32, 0.30, 0.28)
	var dirt := Color(0.45, 0.28, 0.14)
	var grass := Color(0.28, 0.62, 0.22)
	var dark := Color(0.18, 0.16, 0.15)
	for i in w:
		var x0 := i * Game.TILE
		var y0: float = heights[i]
		var y1: float = heights[mini(i + 1, w)]
		var top: float = minf(y0, y1)
		draw_rect(Rect2(x0, top, Game.TILE, 1400 - top), dirt)
		draw_rect(Rect2(x0, top + 18, Game.TILE, 1400 - top), stone.lerp(dark, 0.2))
		draw_rect(Rect2(x0, top, Game.TILE, 8), grass)
		if int(index * w + i) % 7 == 0:
			draw_rect(Rect2(x0 + 4, top + 40, 6, 8), Color(0.55, 0.55, 0.58, 0.7))
	if index == 0:
		draw_rect(Rect2(8, heights[1] - 52, 6, 52), Color(0.9, 0.2, 0.2))
		draw_rect(Rect2(8, heights[1] - 52, 28, 16), Color(0.85, 0.15, 0.15))
