extends CanvasLayer

var last_log := ""
var log_time := 0.0

@onready var hp_bar: ColorRect = $Root/Bars/HpFill
@onready var hunger_bar: ColorRect = $Root/Bars/HungerFill
@onready var thirst_bar: ColorRect = $Root/Bars/ThirstFill
@onready var xp_bar: ColorRect = $Root/Bars/XpFill
@onready var hp_bg: ColorRect = $Root/Bars/HpBg
@onready var hunger_bg: ColorRect = $Root/Bars/HungerBg
@onready var thirst_bg: ColorRect = $Root/Bars/ThirstBg
@onready var xp_bg: ColorRect = $Root/Bars/XpBg
@onready var stats_label: Label = $Root/Stats
@onready var log_label: Label = $Root/Log
@onready var hotbar: HBoxContainer = $Root/Hotbar
@onready var inv_panel: Panel = $Root/InvPanel
@onready var craft_panel: Panel = $Root/CraftPanel
@onready var inv_grid: GridContainer = $Root/InvPanel/Grid
@onready var craft_list: VBoxContainer = $Root/CraftPanel/Scroll/List


func _ready() -> void:
	Game.stats_changed.connect(_refresh_stats)
	Game.inventory_changed.connect(_refresh_inv)
	Game.log_message.connect(_on_log)
	_refresh_stats()
	_refresh_inv()
	inv_panel.visible = false
	craft_panel.visible = false


func _process(delta: float) -> void:
	log_time = maxf(0.0, log_time - delta)
	log_label.modulate.a = clampf(log_time, 0.0, 1.0)
	inv_panel.visible = Game.ui_inventory_open
	craft_panel.visible = Game.ui_craft_open
	_set_fill(hp_bar, hp_bg, Game.hp / Game.max_hp)
	_set_fill(hunger_bar, hunger_bg, Game.hunger / 100.0)
	_set_fill(thirst_bar, thirst_bg, Game.thirst / 100.0)
	_set_fill(xp_bar, xp_bg, float(Game.xp) / float(Game.xp_to_level()))
	_refresh_stats()


func _set_fill(fill: ColorRect, bg: ColorRect, t: float) -> void:
	fill.size.x = bg.size.x * clampf(t, 0.0, 1.0)


func _refresh_stats() -> void:
	var player := get_tree().get_first_node_in_group("player")
	var tiles := 0
	if player:
		tiles = int(player.global_position.x / Game.TILE)
	var wname := "pięści"
	if Game.equipped_weapon != "":
		wname = Game.item_def(Game.equipped_weapon).name
	var aname := "brak"
	if Game.equipped_armor != "":
		aname = Game.item_def(Game.equipped_armor).name
	stats_label.text = "POZ %d   MOC %d   HP %d/%d\nJedzenie %d   Woda %d   Kratka %d\nBroń: %s   Zbroja: %s\nNastępny boss za ~%d kratek (nowy teren: LEWO/PRAWO, zapisany świat zostaje)" % [
		Game.level, Game.player_power(), int(Game.hp), int(Game.max_hp),
		int(Game.hunger), int(Game.thirst), tiles,
		wname, aname, Game.next_boss_tiles(tiles)
	]


func _on_log(text: String) -> void:
	last_log = text
	log_label.text = text
	log_time = 4.0


func _refresh_inv() -> void:
	for c in hotbar.get_children():
		c.queue_free()
	for i in Game.HOTBAR:
		hotbar.add_child(_slot_button(i, true))
	for c in inv_grid.get_children():
		c.queue_free()
	for i in Game.INV_SIZE:
		inv_grid.add_child(_slot_button(i, false))
	for c in craft_list.get_children():
		c.queue_free()
	for recipe in Game.RECIPES:
		var b := Button.new()
		var def: Dictionary = Game.item_def(recipe.id)
		var need_txt := ""
		for k in recipe.need.keys():
			need_txt += "%s %d  " % [Game.item_def(k).name, int(recipe.need[k])]
		b.text = "%s  [%s]" % [def.name, need_txt]
		b.disabled = not Game.can_craft(recipe)
		b.pressed.connect(func() -> void: Game.craft(recipe))
		craft_list.add_child(b)


func _slot_button(i: int, is_hot: bool) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(72, 40) if is_hot else Vector2(110, 36)
	var s = Game.inventory[i]
	if s == null:
		b.text = str(i + 1) if is_hot else "-"
	else:
		b.text = "%s x%d" % [Game.item_def(s.id).name, int(s.count)]
	if is_hot and i == Game.selected_hotbar:
		b.modulate = Color(1.2, 1.15, 0.7)
	b.pressed.connect(func() -> void:
		Game.selected_hotbar = i
		if not is_hot:
			Game.use_selected()
		Game.inventory_changed.emit()
	)
	return b
