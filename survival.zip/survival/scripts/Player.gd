extends CharacterBody2D

const SPEED := 210.0
const JUMP := -430.0
const GRAVITY := 980.0
const ArrowScript := preload("res://scripts/Arrow.gd")

var facing := 1
var attack_cd := 0.0
var invuln := 0.0
var interact_area: Area2D
var slash: Area2D
var anim_slash := 0.0

@onready var vis: Node2D = $Visual
@onready var cam: Camera2D = $Camera2D


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1
	_build_visual()
	_build_areas()
	floor_snap_length = 8


func _build_visual() -> void:
	var head := ColorRect.new()
	head.size = Vector2(14, 14)
	head.position = Vector2(-7, -36)
	head.color = Color(0.95, 0.78, 0.62)
	vis.add_child(head)
	var hair := ColorRect.new()
	hair.size = Vector2(16, 6)
	hair.position = Vector2(-8, -40)
	hair.color = Color(0.35, 0.18, 0.08)
	vis.add_child(hair)
	var body := ColorRect.new()
	body.name = "Body"
	body.size = Vector2(16, 16)
	body.position = Vector2(-8, -22)
	body.color = Color(0.2, 0.55, 0.35)
	vis.add_child(body)
	var legs := ColorRect.new()
	legs.size = Vector2(14, 14)
	legs.position = Vector2(-7, -6)
	legs.color = Color(0.22, 0.22, 0.38)
	vis.add_child(legs)


func _build_areas() -> void:
	interact_area = Area2D.new()
	interact_area.collision_layer = 0
	interact_area.collision_mask = 8
	var ishape := CollisionShape2D.new()
	var irect := RectangleShape2D.new()
	irect.size = Vector2(36, 40)
	ishape.shape = irect
	ishape.position = Vector2(0, -16)
	interact_area.add_child(ishape)
	add_child(interact_area)

	slash = Area2D.new()
	slash.collision_layer = 0
	slash.collision_mask = 4
	slash.monitoring = false
	var sshape := CollisionShape2D.new()
	var srect := RectangleShape2D.new()
	srect.size = Vector2(38, 28)
	sshape.shape = srect
	sshape.position = Vector2(24, -16)
	slash.add_child(sshape)
	add_child(slash)

	var hurt := Area2D.new()
	hurt.collision_layer = 0
	hurt.collision_mask = 16
	var hshape := CollisionShape2D.new()
	var hrect := RectangleShape2D.new()
	hrect.size = Vector2(18, 32)
	hshape.shape = hrect
	hshape.position = Vector2(0, -16)
	hurt.add_child(hshape)
	hurt.area_entered.connect(_on_hurt_area)
	add_child(hurt)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y += GRAVITY * delta
	var dir := Input.get_axis("move_left", "move_right")
	if dir != 0.0:
		facing = 1 if dir > 0.0 else -1
		velocity.x = dir * SPEED
		vis.scale.x = float(facing)
	else:
		velocity.x = move_toward(velocity.x, 0.0, SPEED * 6.0 * delta)
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP
	move_and_slide()
	attack_cd = maxf(0.0, attack_cd - delta)
	invuln = maxf(0.0, invuln - delta)
	anim_slash = maxf(0.0, anim_slash - delta)
	if anim_slash <= 0.0:
		slash.monitoring = false
	_update_armor_color()
	if global_position.y > 1600.0:
		Game.take_damage(999)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("attack"):
		_try_attack()
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_try_attack()
	elif event.is_action_pressed("shoot"):
		_try_shoot()
	elif event.is_action_pressed("interact"):
		_try_interact()
	elif event.is_action_pressed("use_item"):
		Game.use_selected()
	elif event.is_action_pressed("inventory"):
		Game.ui_inventory_open = not Game.ui_inventory_open
		if Game.ui_inventory_open:
			Game.ui_craft_open = false
		Game.inventory_changed.emit()
	elif event.is_action_pressed("craft"):
		Game.ui_craft_open = not Game.ui_craft_open
		if Game.ui_craft_open:
			Game.ui_inventory_open = false
		Game.inventory_changed.emit()
	elif event is InputEventKey and event.pressed and not event.echo:
		var k: int = event.physical_keycode
		if k >= KEY_1 and k <= KEY_8:
			Game.selected_hotbar = k - KEY_1
			Game.inventory_changed.emit()


func _try_attack() -> void:
	if attack_cd > 0.0:
		return
	if Game.weapon_is_ranged():
		_try_shoot()
		return
	attack_cd = 0.38
	anim_slash = 0.16
	slash.position.x = 10.0 * facing
	slash.scale.x = float(facing)
	slash.monitoring = true
	await get_tree().physics_frame
	await get_tree().physics_frame
	var hit_nodes: Dictionary = {}
	for a in slash.get_overlapping_bodies():
		if a.has_method("hit"):
			a.hit(Game.player_damage(), Game.player_power())
			hit_nodes[a] = true
	for a in slash.get_overlapping_areas():
		var p: Node = a.get_parent()
		if p and p.has_method("hit") and not hit_nodes.has(p):
			p.hit(Game.player_damage(), Game.player_power())
			hit_nodes[p] = true


func _try_shoot() -> void:
	if attack_cd > 0.0:
		return
	if not Game.weapon_is_ranged():
		Game.log_message.emit("Załóż łuk (Q na łuku w hotbarze).")
		return
	attack_cd = 0.55
	var p: Area2D = ArrowScript.new()
	p.setup(facing, Game.player_damage(), Game.player_power())
	p.global_position = global_position + Vector2(18 * facing, -20)
	get_parent().add_child(p)


func _try_interact() -> void:
	for a in interact_area.get_overlapping_areas():
		var n: Node = a
		if n.has_method("interact"):
			n.interact()
			return
		if n.get_parent() and n.get_parent().has_method("interact"):
			n.get_parent().interact()
			return


func _on_hurt_area(area: Area2D) -> void:
	if invuln > 0.0:
		return
	if area.get("damage") != null:
		invuln = 0.7
		Game.take_damage(float(area.damage))


func _update_armor_color() -> void:
	var body := vis.get_node_or_null("Body")
	if body == null:
		return
	if Game.equipped_armor == "":
		body.color = Color(0.2, 0.55, 0.35)
	else:
		body.color = Game.item_def(Game.equipped_armor).color
