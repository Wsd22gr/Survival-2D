extends Node2D
class_name TreeProp


func _ready() -> void:
	var trunk := ColorRect.new()
	trunk.size = Vector2(8, 36)
	trunk.position = Vector2(-4, -36)
	trunk.color = Color(0.4, 0.25, 0.12)
	add_child(trunk)
	var leaves := ColorRect.new()
	leaves.size = Vector2(28, 22)
	leaves.position = Vector2(-14, -54)
	leaves.color = Color(0.18, 0.52, 0.2)
	add_child(leaves)
	var leaves2 := ColorRect.new()
	leaves2.size = Vector2(20, 16)
	leaves2.position = Vector2(-10, -64)
	leaves2.color = Color(0.22, 0.62, 0.24)
	add_child(leaves2)


func persist() -> void:
	pass
