extends Area2D
class_name Chest

var chunk_index := 0
var ent_ref: Dictionary = {}


func setup(cindex: int, ent: Dictionary) -> void:
	chunk_index = cindex
	ent_ref = ent
	collision_layer = 8
	collision_mask = 0
	monitoring = false
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(22, 18)
	cs.shape = r
	add_child(cs)
	var box := ColorRect.new()
	box.size = Vector2(22, 16)
	box.position = Vector2(-11, -16)
	box.color = Color(0.55, 0.32, 0.1)
	add_child(box)
	var lid := ColorRect.new()
	lid.size = Vector2(22, 5)
	lid.position = Vector2(-11, -21)
	lid.color = Color(0.7, 0.45, 0.12)
	add_child(lid)
	var lock := ColorRect.new()
	lock.size = Vector2(4, 4)
	lock.position = Vector2(-2, -10)
	lock.color = Color(0.9, 0.75, 0.2)
	add_child(lock)


func interact() -> void:
	if bool(ent_ref.get("opened", false)):
		return
	ent_ref.opened = true
	var rng := Game.rng_for_chunk(chunk_index)
	rng.randf()
	var pool := ["wood", "stone", "iron", "leather", "meat", "water", "herb", "bow"]
	var n := rng.randi_range(2, 4)
	for _i in n:
		var id: String = pool[rng.randi_range(0, pool.size() - 1)]
		var c := rng.randi_range(1, 3)
		Game.add_item(id, c)
		Game.log_message.emit("Skrzynia: %s x%d" % [Game.item_def(id).name, c])
	if rng.randf() < 0.12:
		Game.add_item("iron_sword", 1)
		Game.log_message.emit("Skrzynia: Żelazny miecz!")
	queue_free()


func persist() -> void:
	pass
