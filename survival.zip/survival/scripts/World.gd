extends Node2D

const LOAD_RADIUS := 3
const UNLOAD_RADIUS := 5
const ChunkScript := preload("res://scripts/Chunk.gd")
const EnemyScript := preload("res://scripts/Enemy.gd")
const ChestScript := preload("res://scripts/Chest.gd")
const TrapScript := preload("res://scripts/Trap.gd")
const TreeScript := preload("res://scripts/TreeProp.gd")
const LootScript := preload("res://scripts/Loot.gd")

@onready var chunks_root: Node2D = $Chunks
@onready var entities_root: Node2D = $Entities
@onready var player: CharacterBody2D = $Player

var loaded_chunks: Dictionary = {}
var save_timer := 0.0
var needs_timer := 0.0


func _ready() -> void:
	if Game.loaded_save:
		player.global_position = Vector2(Game.player_x, Game.player_y)
	else:
		var gy := Game.ground_height(0)
		player.global_position = Vector2(40, gy - 48)
	Game.player_died.connect(_on_death)
	_stream_chunks(true)


func _process(delta: float) -> void:
	_stream_chunks(false)
	_check_bosses()
	save_timer += delta
	needs_timer += delta
	if needs_timer >= 0.25:
		needs_timer = 0.0
		Game.tick_needs(0.25)
	if save_timer >= 8.0:
		save_timer = 0.0
		Game.save_game(player.global_position.x, player.global_position.y)


func _stream_chunks(force: bool) -> void:
	var cx := int(floor(player.global_position.x / float(Game.CHUNK_TILES * Game.TILE)))
	for i in range(cx - LOAD_RADIUS, cx + LOAD_RADIUS + 1):
		if not loaded_chunks.has(i):
			_load_chunk(i)
	if force:
		return
	var to_drop: Array = []
	for idx in loaded_chunks.keys():
		if absi(int(idx) - cx) > UNLOAD_RADIUS:
			to_drop.append(idx)
	for idx in to_drop:
		_unload_chunk(int(idx))


func _load_chunk(index: int) -> void:
	var state: Dictionary = Game.ensure_chunk_state(index)
	var chunk: Node = ChunkScript.new()
	chunks_root.add_child(chunk)
	chunk.build(index)
	loaded_chunks[index] = chunk
	for ent in state.entities:
		_spawn_entity(index, ent)


func _unload_chunk(index: int) -> void:
	if not loaded_chunks.has(index):
		return
	var chunk: Node = loaded_chunks[index]
	if is_instance_valid(chunk):
		chunk.queue_free()
	loaded_chunks.erase(index)
	for child in entities_root.get_children():
		if child.get("is_boss"):
			continue
		if child.has_meta("chunk") and int(child.get_meta("chunk")) == index:
			if child.has_method("persist"):
				child.persist()
			child.queue_free()


func _spawn_entity(index: int, ent: Dictionary) -> void:
	var origin_x := index * Game.CHUNK_TILES * Game.TILE
	var tx := int(ent.get("tx", 0))
	var wx := origin_x + tx * Game.TILE + Game.TILE * 0.5
	var gy := Game.ground_height(index * Game.CHUNK_TILES + tx)
	match str(ent.get("kind", "")):
		"tree":
			var t: Node2D = TreeScript.new()
			t.position = Vector2(wx, gy)
			t.set_meta("chunk", index)
			entities_root.add_child(t)
		"chest":
			if bool(ent.get("opened", false)):
				return
			var c: Area2D = ChestScript.new()
			c.setup(index, ent)
			c.position = Vector2(wx, gy - 10)
			c.set_meta("chunk", index)
			entities_root.add_child(c)
		"trap":
			var tr: Area2D = TrapScript.new()
			tr.setup(index, ent)
			tr.position = Vector2(wx, gy - 6)
			tr.set_meta("chunk", index)
			entities_root.add_child(tr)
		"mob":
			if not bool(ent.get("alive", true)):
				return
			var e = EnemyScript.new()
			e.setup(str(ent.get("etype", "slime")), index, ent, false)
			e.position = Vector2(wx, gy - 18)
			e.set_meta("chunk", index)
			e.died.connect(_on_mob_died)
			entities_root.add_child(e)


func _check_bosses() -> void:
	var tiles := int(player.global_position.x / Game.TILE)
	var dist := absi(tiles)
	if dist < Game.FIRST_BOSS_TILES:
		return
	var milestone := Game.boss_tile_for_distance(dist)
	for sign_dir in [-1, 1]:
		var key := "%d" % (sign_dir * milestone)
		if Game.spawned_bosses.get(key, "") == "dead":
			continue
		if sign_dir < 0 and tiles > -milestone + 80:
			continue
		if sign_dir > 0 and tiles < milestone - 80:
			continue
		if _boss_exists(key):
			continue
		_spawn_boss(sign_dir * milestone, key)


func _boss_exists(key: String) -> bool:
	for child in entities_root.get_children():
		if child.get("boss_key") == key and is_instance_valid(child):
			return true
	return false


func _spawn_boss(tile_x: int, key: String) -> void:
	Game.spawned_bosses[key] = "alive"
	var wx := tile_x * Game.TILE
	var gy := Game.ground_height(tile_x)
	var e = EnemyScript.new()
	var fake := {"kind": "mob", "tx": 0, "alive": true, "etype": "boss", "boss_key": key}
	e.setup("boss", int(floor(float(tile_x) / Game.CHUNK_TILES)), fake, true)
	e.position = Vector2(wx, gy - 40)
	e.set_meta("chunk", int(floor(float(tile_x) / Game.CHUNK_TILES)))
	e.died.connect(_on_mob_died)
	entities_root.add_child(e)
	Game.log_message.emit("BOSS pojawia się na kratce %d!" % tile_x)


func _on_mob_died(enemy, drops: Array, xp_amount: int) -> void:
	Game.add_xp(xp_amount)
	for d in drops:
		Game.add_item(d.id, int(d.count))
	if enemy.is_boss and enemy.boss_key != "":
		Game.spawned_bosses[enemy.boss_key] = "dead"
		Game.log_message.emit("Boss pokonany! Świat idzie dalej — kolejny boss za 10000 kratek.")
	Game.log_message.emit("Łup: %s  (+%d XP)" % [_fmt_drops(drops), xp_amount])


func _fmt_drops(drops: Array) -> String:
	if drops.is_empty():
		return "nic"
	var parts: PackedStringArray = []
	for d in drops:
		parts.append("%s x%d" % [Game.item_def(d.id).name, int(d.count)])
	return ", ".join(parts)


func _on_death() -> void:
	player.global_position = Vector2(40, Game.ground_height(0) - 48)
	Game.hp = Game.max_hp * 0.5
	Game.hunger = maxf(Game.hunger, 35.0)
	Game.thirst = maxf(Game.thirst, 35.0)
	Game.log_message.emit("Omdlenie... budzisz się przy starcie.")
	Game.stats_changed.emit()


func spawn_loot(world_pos: Vector2, item_id: String, count: int) -> void:
	var l: Area2D = LootScript.new()
	l.setup(item_id, count)
	l.global_position = world_pos
	entities_root.add_child(l)
