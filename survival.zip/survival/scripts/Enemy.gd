extends CharacterBody2D
class_name Enemy

signal died(enemy: Enemy, drops: Array, xp_amount: int)

var etype := "slime"
var max_hp := 30.0
var hp := 30.0
var power := 10
var damage := 8
var speed := 70.0
var xp_reward := 8
var is_boss := false
var boss_key := ""
var chunk_index := 0
var ent_ref: Dictionary = {}
var attack_cd := 0.0
var flash := 0.0
var facing := -1
var label: Label
var bar: ColorRect
var bar_bg: ColorRect
var vis: Node2D


func setup(kind: String, cindex: int, ent: Dictionary, boss: bool) -> void:
	etype = kind
	chunk_index = cindex
	ent_ref = ent
	is_boss = boss
	boss_key = str(ent.get("boss_key", ""))
	collision_layer = 4
	collision_mask = 1
	_stats_from_type()
	_build()


func _stats_from_type() -> void:
	var dist := absi(chunk_index * Game.CHUNK_TILES)
	match etype:
		"slime":
			max_hp = 22 + dist / 400.0
			power = 8 + dist / 500
			damage = 6
			speed = 55
			xp_reward = 6
		"goblin":
			max_hp = 34 + dist / 280.0
			power = 14 + dist / 380
			damage = 9
			speed = 85
			xp_reward = 10
		"wolf":
			max_hp = 40 + dist / 250.0
			power = 18 + dist / 320
			damage = 12
			speed = 110
			xp_reward = 14
		"skeleton":
			max_hp = 55 + dist / 200.0
			power = 24 + dist / 260
			damage = 14
			speed = 80
			xp_reward = 18
		"brute":
			max_hp = 90 + dist / 160.0
			power = 32 + dist / 200
			damage = 18
			speed = 60
			xp_reward = 26
		"boss":
			max_hp = 420 + dist / 40.0
			power = 80 + dist / 80
			damage = 28
			speed = 95
			xp_reward = 120
	hp = max_hp


func _build() -> void:
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	var w := 22.0 if not is_boss else 48.0
	var h := 22.0 if not is_boss else 52.0
	rect.size = Vector2(w, h)
	shape.shape = rect
	shape.position = Vector2(0, -h * 0.5)
	add_child(shape)

	vis = Node2D.new()
	add_child(vis)
	var body := ColorRect.new()
	body.name = "Body"
	body.size = Vector2(w, h)
	body.position = Vector2(-w * 0.5, -h)
	body.color = _color()
	vis.add_child(body)
	if is_boss:
		var crown := ColorRect.new()
		crown.size = Vector2(20, 8)
		crown.position = Vector2(-10, -h - 8)
		crown.color = Color(0.95, 0.8, 0.15)
		vis.add_child(crown)

	var hitbox := Area2D.new()
	hitbox.collision_layer = 4
	hitbox.collision_mask = 2
	var hs := CollisionShape2D.new()
	var hr := RectangleShape2D.new()
	hr.size = Vector2(w + 4, h)
	hs.shape = hr
	hs.position = Vector2(0, -h * 0.5)
	hitbox.add_child(hs)
	hitbox.body_entered.connect(_on_touch_player)
	add_child(hitbox)

	bar_bg = ColorRect.new()
	bar_bg.size = Vector2(36 if not is_boss else 70, 5)
	bar_bg.color = Color(0.1, 0.1, 0.1, 0.8)
	bar_bg.position = Vector2(-bar_bg.size.x * 0.5, -h - 22)
	add_child(bar_bg)
	bar = ColorRect.new()
	bar.size = bar_bg.size
	bar.color = Color(0.85, 0.15, 0.12)
	bar.position = bar_bg.position
	add_child(bar)
	label = Label.new()
	label.position = Vector2(-28, -h - 40)
	label.add_theme_font_size_override("font_size", 12)
	label.add_theme_color_override("font_color", Color(1, 0.92, 0.35))
	add_child(label)
	_refresh_bars()


func _color() -> Color:
	match etype:
		"slime":
			return Color(0.35, 0.85, 0.3)
		"goblin":
			return Color(0.25, 0.55, 0.22)
		"wolf":
			return Color(0.45, 0.45, 0.5)
		"skeleton":
			return Color(0.9, 0.88, 0.8)
		"brute":
			return Color(0.55, 0.2, 0.18)
		"boss":
			return Color(0.75, 0.12, 0.08)
	return Color.WHITE


func _physics_process(delta: float) -> void:
	if not is_inside_tree():
		return
	var player := get_tree().get_first_node_in_group("player")
	if player == null:
		return
	if not is_on_floor():
		velocity.y += 980.0 * delta
	var to_p: float = player.global_position.x - global_position.x
	if absf(to_p) > 8.0:
		facing = 1 if to_p > 0.0 else -1
		velocity.x = signf(to_p) * speed
	else:
		velocity.x = 0.0
	if is_on_wall() and is_on_floor():
		velocity.y = -320.0
	move_and_slide()
	attack_cd = maxf(0.0, attack_cd - delta)
	flash = maxf(0.0, flash - delta)
	var body := vis.get_node_or_null("Body")
	if body:
		body.color = Color.WHITE if flash > 0.0 else _color()
	_refresh_bars()
	if absf(global_position.x - player.global_position.x) < (28.0 if is_boss else 20.0) and absf(global_position.y - player.global_position.y) < 40.0:
		_hit_player()


func _hit_player() -> void:
	if attack_cd > 0.0:
		return
	attack_cd = 0.85 if is_boss else 1.05
	Game.take_damage(float(damage) * (1.0 + power * 0.01))


func _on_touch_player(body: Node) -> void:
	if body.is_in_group("player"):
		_hit_player()


func hit(raw_damage: int, attacker_power: int) -> void:
	var dmg := maxf(1.0, float(raw_damage) * (1.0 + attacker_power * 0.015) - float(power) * 0.08)
	hp -= dmg
	flash = 0.12
	_refresh_bars()
	if hp <= 0.0:
		_die()


func _refresh_bars() -> void:
	if label:
		label.text = "MOC %d" % power
	if bar and bar_bg:
		var t := clampf(hp / max_hp, 0.0, 1.0)
		bar.size.x = bar_bg.size.x * t


func _die() -> void:
	if ent_ref.has("alive"):
		ent_ref.alive = false
	var drops := _roll_drops()
	died.emit(self, drops, xp_reward)
	queue_free()


func persist() -> void:
	pass


func _roll_drops() -> Array:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var out: Array = []
	match etype:
		"slime":
			if rng.randf() < 0.7:
				out.append({"id": "herb", "count": rng.randi_range(1, 2)})
			if rng.randf() < 0.4:
				out.append({"id": "water", "count": 1})
		"goblin":
			out.append({"id": "wood", "count": rng.randi_range(1, 3)})
			if rng.randf() < 0.5:
				out.append({"id": "iron", "count": 1})
			if rng.randf() < 0.25:
				out.append({"id": "wood_sword", "count": 1})
		"wolf":
			out.append({"id": "leather", "count": rng.randi_range(1, 3)})
			out.append({"id": "meat", "count": rng.randi_range(1, 2)})
		"skeleton":
			out.append({"id": "iron", "count": rng.randi_range(1, 3)})
			if rng.randf() < 0.3:
				out.append({"id": "bow", "count": 1})
			if rng.randf() < 0.2:
				out.append({"id": "iron_sword", "count": 1})
		"brute":
			out.append({"id": "iron", "count": rng.randi_range(2, 5)})
			out.append({"id": "stone", "count": rng.randi_range(2, 4)})
			if rng.randf() < 0.2:
				out.append({"id": "iron_armor", "count": 1})
		"boss":
			out.append({"id": "boss_blade", "count": 1})
			out.append({"id": "potion", "count": 3})
			out.append({"id": "iron", "count": 12})
			out.append({"id": "steel_armor", "count": 1})
	if rng.randf() < 0.15:
		out.append({"id": "stone", "count": rng.randi_range(1, 2)})
	return out
